package com.example.pushup_plank_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SettingsGoal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_goal);
    }
}